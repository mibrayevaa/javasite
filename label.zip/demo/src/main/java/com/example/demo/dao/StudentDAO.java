package com.example.demo.dao;

import com.example.demo.model.Student;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
public class StudentDAO {
    private static int id = 0;
    private List<Student> students = new ArrayList<>();
    {
        students.add(new Student(++id, "Daniyar", "ITEM"));
    }

    public List<Student> getStudents() {
        return students;
    }

    public Student find(int id) {
        for(Student student : students) {
            if(student.getId() == id)
                return student;
        }
        return null;
    }

    public void save(Student newStudent) {
        newStudent.setId(++id);
        students.add(newStudent);
    }

    public void delete(int id) {
        students.remove(find(id));
    }

    public void update(int id, Student updatedStudent) {
        Student student = find(id);
        student.setName(updatedStudent.getName());
        student.setGroup(updatedStudent.getGroup());
    }
    public Student getDate(int id){
        Date date = new Date();
        
        return date;
    }
}
