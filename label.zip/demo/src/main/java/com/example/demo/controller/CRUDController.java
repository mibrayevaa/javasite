package com.example.demo.controller;

import com.example.demo.dao.StudentDAO;
import com.example.demo.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

//localhost:8080/api1.0/students/1
@Controller
@RequestMapping("/api1.0/students")
public class CRUDController {

    private StudentDAO studentDAO;

    @Autowired
    public CRUDController(StudentDAO studentDAO) {
        this.studentDAO = studentDAO;
    }

    @GetMapping
    public String index(Model model) {
        model.addAttribute("students", studentDAO.getStudents());
        return "index";
    }

    @GetMapping("/{id}")
    public String filter(@PathVariable("id") int id, Model model) {
        model.addAttribute("student", studentDAO.find(id));
        return "show";
    }

    @GetMapping("/new")
    public String newStudent(Model model) {
        model.addAttribute("student", new Student());
        return "create";
    }

    @PostMapping
    public String create(@ModelAttribute("student") Student student) {
        studentDAO.save(student);
        return "redirect:/api1.0/students";
    }

    @GetMapping("/{id}/edit")
    public String edit(@PathVariable("id") int id, Model model) {
        model.addAttribute("student", studentDAO.find(id));
        System.out.println(studentDAO.find(id));
        return "edit";
    }

    @DeleteMapping("/{id}")
    public String deleteStudent(@PathVariable("id") int id) {
        studentDAO.delete(id);
        return "redirect:/api1.0/students";
    }

    @PutMapping("/{id}")
    public String update(@PathVariable("id") int id, @ModelAttribute("student") Student updatedStudent) {
        studentDAO.update(id, updatedStudent);
        return "redirect:/api1.0/students";
    }
}

